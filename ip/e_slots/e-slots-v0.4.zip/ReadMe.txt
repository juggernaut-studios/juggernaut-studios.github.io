#1 Download the GitBash software for windows
#2 Create a Repo [on github on browser]
#3 On local Machine - 
    git clone <repor url>
add folders or make changes to existing files
git add *
we need to commit the changes
git commit -m "Message goes here"
we need to push the changes to master copy
git push origin master
#4 Update the content <if some1 else has committed to same >
git pull origin <branch name> | master